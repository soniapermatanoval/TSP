#Program Jadwal Kuliah 

nama = "Nia"
mata_kuliah = "Kewarganegaraan"

print(f"Selamat datang {nama}")

print(f"Silahkan pilih jadwal kelas  {mata_kuliah}")
print("1. kelas A: Senin, 16.00 - 17.40")
print("2. kelas B: Rabu, 11.00 - 12.50")
print("3. kelas C: Kamis, 13.30 - 15.10")
print("4. kelas D: Jumat,  09.20 - 11.00")

opsi = int(input("Pilih opsi Jadwal :")) 
if opsi == 1:
    jadwal = "kelas A | Senin, 16.00 - 17.40"
elif opsi == 2:
    jadwal = "kelas B | Rabu, 11.00 - 12.50"
elif opsi == 3: 
    jadwal = "kelas C | Kamis, 13.30- 15.10"
elif opsi == 4:
    jadwal = "kelas D | Jumat, 09.20- 11.00"
else:
    jadwal =print("Pilihan anda tidak tersedia")
   
print("-------------------------------------")

mata_kuliah = jadwal 
print(f"Nama : {nama}")
print(f"Jadwal Kewarganegaraan : {jadwal}")
